import java.util.Scanner;
import java.util.ArrayList;
import static java.util.Arrays.asList;
import java.util.*;

public class NFL{
    public static void main(String[] args) {

        Scanner user_input = new Scanner( System.in );

        String userSelect = "";

        List<String> teams = new ArrayList<>();

        teams.add("New England Patriots");
        teams.add("New Orleans Saints");

        OffensivePlayer newPlayer = new OffensivePlayer(22, 2, 3147, 110.9, "QB", "Tom Brady", 40, 76, 225);

        
        while(true){

            System.out.println("Please choose a team: " + teams.get(0) + " " + teams.get(1));

            userSelect = user_input.next();

            System.out.println("You chose: " + userSelect);


        }
    
    }
}

public abstract class Player {

    public String name;

    public int age;

    public double height;

    public double weight;

    public Player(String n, int a, double h, double w){
        name = n;
        age = a;
        height = h;
        wight = w;
    }

    public static void printFullStats(){

    }

}

public class Celebrator {

    public static void main(String[] args) {

    
    }

    public static void celebrate(){

    }

}

public class OffensivePlayer extends Player {

    int touchdowns;

    int intercepts;

    int yards;

    double rtg;

    String position;

    public OffensivePlayer(int t, int i, int y, double r, String p, String n, int a, double h, double w ){
        super(n, a, h, w);
        touchdowns = t;
        intercepts = i;
        yards = y;
        rtg = r;
        position = p;
    }

    //OffensivePlayer myPlayer = new OffensivePlayer(22, 2, 3147, 110.9, "QB", "Tom Brady", 40, 76, 225);

    public static void main(String[] args) {

    
    }
    public static void printFullStats(){ //Override

    }

    public static void celebrate(){

    }

}

public class DefensivePlayer extends Player {

    int tackles;

    double sck;

    int ff;

    int intercepts;

    String position;

    public static void main(String[] args) {

    
    }

    public DefensivePlayer(int t, double s, int f, int i, String p, String n, int a, double h, double w ){
        super(n, a, h, w);
        tackles = t;
        sck = s;
        ff = f;
        intercepts = i;
        position = p;
    }

    public static void printFullStats(){ //Override

    }

    public static void celebrate(){

    }

}

public class PlayerManager {

    List<String> availablePlayers = new ArrayList<>();

    List<String> currentRoster = new ArrayList<>();

    public static void main(String[] args) {

    
    }

    public static void listOffensivePlayers(){

    }

    public static void listDeffensivePlayers(){

    }

    public static void draftPlayer(Player myPlayer){

    }

    public static void removePlayerFromRoster(Player myPlayer){

    }

    public static void displayStatsForPlayer(Player myPlayer){

    }

}